#!/usr/bin/env bash
set -euo pipefail
kit_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$kit_dir/qmk_firmware"
make keychron/q5_max/ansi_encoder:alastair SKIP_GIT=yes -j"${JOBS:-4}"
printf '\nBuilt firmware: %s\n' "$kit_dir/qmk_firmware/keychron_q5_max_ansi_encoder_alastair.bin"
